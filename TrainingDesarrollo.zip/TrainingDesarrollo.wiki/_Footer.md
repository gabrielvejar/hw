![footer_trainee_5](footer_trainee_5.png)
