# Planificación Training Desarrollo

<table>
    <tr>
        <th>Día</th>
        <th>Descripción</th>
		<th>Ubicación</th>
		<th>Hora de Inicio</th>
		<th>Hora de Término</th>
        <th>Contenido</th>
		<th>Tipo de Actividad</th>
		<th>Área Responsable</th>
		<th>Nombre de Responsable</th>
    </tr>
    </tr>
		<tr>
        <td>11</td>
		<td>Capacitación Maestro</td>
		<td></td>
		<td>08:45</td>
		<td>10:35</td>
		<td>Maestros: Cliente Proveedor / Productos y Servicios / Sucursal</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>11</td>
		<td>Kahoot! - Maestro</td>
		<td></td>
		<td>10:35</td>
		<td>10:50</td>
		<td>Maestros: Cliente Proveedor / Productos y Servicios / Sucursal</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>11</td>
		<td>Actividad practica - Maestros</td>
		<td>201</td>
		<td>10:50</td>
		<td>12:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>11</td>
		<td>Capacitación Ventas</td>
		<td></td>
		<td>12:00</td>
		<td>13:00</td>
		<td>Emisión de documentos Electrónicos: Factura,Nota de Credito, Nota de Debito, Guía de Despacho, Boleta Electrónica, Liquidación Factura, Factura de Compra Electrónica y Factura de exportación</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>11</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>11</td>
		<td>Capacitación Ventas</td>
		<td></td>
		<td>13:45</td>
		<td>16:00</td>
		<td>Emisión de documentos Electrónicos: Factura,Nota de Credito, Nota de Debito, Guía de Despacho, Boleta Electrónica, Liquidación Factura, Factura de Compra Electrónica y Factura de exportación</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>11</td>
		<td>Kahoot! - Maestro</td>
		<td></td>
		<td>16:00</td>
		<td>16:15</td>
		<td>Emisión de documentos Electrónicos: Factura,Nota de Credito, Nota de Debito, Guía de Despacho, Boleta Electrónica, Liquidación Factura, Factura de Compra Electrónica y Factura de exportación</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>11</td>
		<td>Actividad practica - Ventas</td>
		<td>201</td>
		<td>16:15</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Capacitación Compras</td>
		<td></td>
		<td>08:45</td>
		<td>10:35</td>
		<td>Compra: Panel DTE Recibidos, Panel Acuse Comercial, Ingreso de Documentos Manuales</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Kahoot! - Compras</td>
		<td></td>
		<td>10:35</td>
		<td>10:50</td>
		<td>Compra: Panel DTE Recibidos, Panel Acuse Comercial, Ingreso de Documentos Manuales</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Actividad practica - Compras</td>
		<td>201</td>
		<td>10:50</td>
		<td>11:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Capacitación - Contabilidad Basica</td>
		<td></td>
		<td>10:50</td>
		<td>13:45</td>
		<td>Libro de Compra, Libro de Ventas y Libro de IVA</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Kahoot! - Contabilidad Basica</td>
		<td></td>
		<td>13:45</td>
		<td>14:00</td>
		<td></td>
		<td>Grupal</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Almuerzo</td>
		<td></td>
		<td>14:00</td>
		<td>14:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Actividad practica - Contabilidad Basica</td>
		<td>201</td>
		<td>14:45</td>
		<td>15:05</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Capacitación Administrador</td>
		<td></td>
		<td>15:05</td>
		<td>18:15</td>
		<td>Folios, Notificaciones, Usuarios, Pago en linea, Respaldo XML, Dispositivo, Datos Empresa, Cambio de Rango, Cesión de Documentos</td>
		<td>Grupal</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>12</td>
		<td>Kahoot! - Administrador</td>
		<td></td>
		<td>18:15</td>
		<td>18:30</td>
		<td>Folios, Notificaciones, Usuarios, Pago en linea, Respaldo XML, Dispositivo, Datos Empresa, Cambio de Rango, Cesión de Documentos</td>
		<td>Grupal</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Actividad practica - Administrador</td>
		<td>201</td>
		<td>08:45</td>
		<td>10:00</td>
		<td>Folios, Notificaciones, Usuarios, Pago en linea, Respaldo XML, Dispositivo, Datos Empresa, Cambio de Rango, Cesión de Documentos</td>
		<td>Grupal</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Capacitación - Remuneraciones</td>
		<td></td>
		<td>10:00</td>
		<td>13:00</td>
		<td>Maestro Personal, Isapre, AFP, Haberes y Descuentos, Nomina Mensual, Liquidación, Parametros Generales y reportes</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Kahoot! - Remuneraciones</td>
		<td></td>
		<td>14:00</td>
		<td>14:15</td>
		<td>Maestro Personal, Isapre, AFP, Haberes y Descuentos, Nomina Mensual, Liquidación, Parametros Generales y reportes</td>
		<td>Grupal</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Actividad practica - Remuneraciones</td>
		<td>201</td>
		<td>14:15</td>
		<td>15:10</td>
		<td>Maestro Personal, Isapre, AFP, Haberes y Descuentos, Nomina Mensual, Liquidación, Parametros Generales y reportes</td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Capacitación - Comercial</td>
		<td></td>
		<td>15:10</td>
		<td>16:30</td>
		<td>Orden de Trabajo, Cotización, Orden de Compra</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Kahoot! - Comercial</td>
		<td></td>
		<td>16:30</td>
		<td>16:45</td>
		<td>Orden de Trabajo, Cotización, Orden de Compra</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Actividad practica - Comercial</td>
		<td>201</td>
		<td>16:45</td>
		<td>17:15</td>
		<td>Orden de Trabajo, Cotización, Orden de Compra</td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Capacitación - Contrato</td>
		<td></td>
		<td>17:15</td>
		<td>18:00</td>
		<td>Agregar/Modificar, Listado, Facturar Contratos</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>13</td>
		<td>Kahoot! - Contrato</td>
		<td></td>
		<td>18:00</td>
		<td>18:15</td>
		<td>Agregar/Modificar, Listado, Facturar Contratos</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>14</td>
		<td>Actividad practica - Contrato</td>
		<td>201</td>
		<td>08:45</td>
		<td>10:00</td>
		<td>Agregar/Modificar, Listado, Facturar Contratos</td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>14</td>
		<td>Capacitación - Existencia</td>
		<td></td>
		<td>10:00</td>
		<td>12:30</td>
		<td>Bodega, Tarjeta, Guía de ajuste, Ingreso Panel DTE recibidos, Ingreso Libro de Compras, Egreso desde Ventas, Funcionalidades desde maestro - producto/servicios</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>14</td>
		<td>Kahoot! - Contrato</td>
		<td></td>
		<td>12:30</td>
		<td>12:45</td>
		<td>Bodega, Tarjeta, Guía de ajuste, Ingreso Panel DTE recibidos, Ingreso Libro de Compras, Egreso desde Ventas, Funcionalidades desde maestro - producto/servicios</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>14</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>14</td>
		<td>Actividad practica - Existencia</td>
		<td>201</td>
		<td>14:00</td>
		<td>15:00</td>
		<td>Agregar/Modificar, Listado, Facturar Contratos</td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>14</td>
		<td>Capacitación - Cuentas Corrientes</td>
		<td></td>
		<td>15:00</td>
		<td>16:45</td>
		<td>Cuentas por cobrar, Deudas por Cliente, Cobranza, Registro anticipo, Cheque a fecha</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>14</td>
		<td>Kahoot! - Cuentas Corrientes</td>
		<td></td>
		<td>16:45</td>
		<td>17:00</td>
		<td>Cuentas por cobrar, Deudas por Cliente, Cobranza, Registro anticipo, Cheque a fecha</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>14</td>
		<td>Actividad practica - Cuentas Corrientes</td>
		<td>201</td>
		<td>17:00</td>
		<td>18:30</td>
		<td>Cuentas por cobrar, Deudas por Cliente, Cobranza, Registro anticipo, Cheque a fecha</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Capacitación - Contabilidad Avanzada</td>
		<td></td>
		<td>08:45</td>
		<td>11:00</td>
		<td>Plan de cuentas, Centralización Compra/venta, Ingreso comprobantes, Libros contables, Balance</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Kahoot! - Contabilidad Avanzada</td>
		<td></td>
		<td>11:00</td>
		<td>11:15</td>
		<td>Plan de cuentas, Centralización Compra/venta, Ingreso comprobantes, Libros contables, Balance</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Actividad practica - Cuentas Corrientes</td>
		<td>201</td>
		<td>11:15</td>
		<td>12:00</td>
		<td>Plan de cuentas, Centralización Compra/venta, Ingreso comprobantes, Libros contables, Balance</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Capacitación - Centro de Costo</td>
		<td></td>
		<td>12:00</td>
		<td>12:45</td>
		<td>Creación, Asignación</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Kahoot! - Centro de Costo</td>
		<td></td>
		<td>12:45</td>
		<td>13:00</td>
		<td>Creación, Asignación</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Actividad practica - Centro de Costo</td>
		<td>201</td>
		<td>14:00</td>
		<td>14:30</td>
		<td>Creación, Asignación</td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Capacitación - Caja Chica</td>
		<td></td>
		<td>14:30</td>
		<td>15:00</td>
		<td>Creación, Asignación</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Kahoot! - Caja Chica</td>
		<td></td>
		<td>15:00</td>
		<td>15:15</td>
		<td>Creación, Asignación</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Actividad practica - Caja Chica</td>
		<td>201</td>
		<td>15:15</td>
		<td>15:45</td>
		<td>Creación, Asignación</td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Capacitación - Comisiones</td>
		<td></td>
		<td>15:45</td>
		<td>16:30</td>
		<td>Creación, Asignación, Carga de comisiones desde Productos</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Kahoot! - Comisiones</td>
		<td></td>
		<td>16:30</td>
		<td>16:45</td>
		<td>Creación, Asignación, Carga de comisiones desde Productos</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Actividad practica - Comisiones</td>
		<td>201</td>
		<td>16:45</td>
		<td>17:15</td>
		<td>Creación, Asignación, Carga de comisiones desde Productos</td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Capacitación - DTETools</td>
		<td></td>
		<td>17:15</td>
		<td>18:15</td>
		<td>Funcionalidades</td>
		<td>Grupal</td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>15</td>
		<td>Kahoot! - DTEtools</td>
		<td></td>
		<td>18:15</td>
		<td>18:30</td>
		<td>Funcionalidades</td>
		<td>Grupal</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
