# Malla Curricular Training Desarrollo

<table>
    <tr>
        <th>N°</th>
        <th>Capacitación</th>
    </tr>
    <tr>
        <td>1</td>
		<td>Herramientas de Desarrollo</td>
    </tr>
    <tr>
        <td>2</td>
		<td>Maquetación Web Desis</td>
    </tr>
    <tr>
        <td>3</td>
		<td>Javascripts</td>
    </tr>
    <tr>
        <td>4</td>
		<td>Base de Datos</td>
    </tr>
    <tr>
        <td>5</td>
		<td>Ajax</td>
    </tr>
    <tr>
        <td>6</td>
		<td>Funciones y Vistas</td>
    </tr>
    <tr>
        <td>7</td>
		<td>Maquetación Web y Comunicación Ajax Avanzado</td>
    </tr>
    <tr>
        <td>8</td>
		<td>Encapsulamiento de Código</td>
    </tr>
    <tr>
        <td>9</td>
		<td>Base de Datos Avanzado</td>
    </tr>
    <tr>
        <td>10</td>
		<td>Estructura y construcción de archivos XML</td>
    </tr>
    <tr>
        <td>11</td>
		<td>Flujo del desarrollo en desis</td>
    </tr>
    <tr>
        <td>12</td>
		<td>Capacitación de Requerimientos</td>
    </tr>
    <tr>
        <td>13</td>
		<td>Capacitación plataforma desis Módulos Básicos</td>
    </tr>
    <tr>
        <td>14</td>
		<td>Capacitación plataforma desis Módulo Cuenta Corriente</td>
    </tr>
    <tr>
        <td>15</td>
		<td>Capacitación plataforma desis Módulo Comercial</td>
    </tr>
    <tr>
        <td>16</td>
		<td>Capacitación plataforma desis Módulo Contratos</td>
    </tr>
    <tr>
        <td>17</td>
		<td>Capacitación plataforma desis Módulo Remuneraciones</td>
    </tr>
    <tr>
        <td>18</td>
		<td>Capacitación plataforma desis Módulo Contabilidad Avanzada</td>
    </tr>
    <tr>
        <td>19</td>
		<td>Capacitación plataforma desis Módulo Existencia</td>
    </tr>
    <tr>
        <td>20</td>
		<td>Capacitación plataforma desis Módulo Integración</td>
    </tr>
    <tr>
        <td>21</td>
		<td>Capacitación plataforma desis Proyecto Mexico</td>
    </tr>
    <tr>
        <td>22</td>
		<td>Capacitación plataforma desis Proyecto Perú</td>
    </tr>
    <tr>
        <td>23</td>
		<td>Capacitación revisión funcional</td>
    </tr>
   <tr>
        <td>24</td>
		<td>Capacitación revisión Técnica</td>
    </tr>
   <tr>
        <td>25</td>
		<td>Capacitación Componentes Desis</td>
    </tr>
   <tr>
        <td>26</td>
		<td>Desarrollo de requerimientos</td>
    </tr>