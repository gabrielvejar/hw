# Actividades Técnicas Trainng Desarrollo

### Actividad Trainng Desarrollo Semana 1

<table>
    <tr>
        <th>Nombre Actividad</th>
        <th>Descripción</th>
		<th>Maquetación Web</th>
		<th>Javascripts</th>
		<th>Base de Datos</th>
        <th>Ajax</th>
		<th>Base de Datos Intermedio</th>
    </tr>
    <tr>
        <th>Formulario de Votación</th>
        <th></th>
		<th>[Link](Actividad_01 - MAQUETACION_v1.pdf)</th>
		<th>[Link](Actividad_02 - VALIDACIONES_v1.pdf)</th>
		<th>[Link](Actividad_03 - COMMAND_v1.pdf)</th>
                <th>[Link](Actividad_04 - AJAX_v1.pdf)</th>
		<th>[Link](Actividad_05 - BASE DE DATOS_v1.pdf)</th>
       </tr>
    <tr>
        <th>Formulario de Suscripción</th>
        <th></th>
		<th>[Link](Actividad_01 - MAQUETACION.pdf)</th>
		<th>[Link](Actividad_02 - VALIDACIONES.pdf)</th>
		<th>[Link](Actividad_03 - COMMAND.pdf)</th>
                <th>[Link](Actividad_04 - AJAX.pdf)</th>
		<th>[Link](Actividad_05 - BASE DE DATOS.pdf)</th>
       </tr>
    <tr>
        <th>Formulario de Agendar Consulta</th>
        <th></th>
		<th>[Link](Actividad_01 - MAQUETACION_V3.pdf)</th>
		<th>[Link](Actividad_02 - VALIDACIONES_V3.pdf)</th>
		<th>[Link](Actividad_03 - COMMAND_V3.pdf)</th>
                <th>[Link](Actividad_04 - AJAX_V3.pdf)</th>
		<th>[Link](Actividad_05 - BASE DE DATOS_V3.pdf)</th>
       </tr>
    <tr>
        <th>Formulario de Arriendo de Canchas</th>
        <th></th>
		<th>[Link](Actividad_01 - MAQUETACION_v4.pdf)</th>
		<th>[Link](Actividad_02 - VALIDACIONES_V4.pdf)</th>
		<th>[Link](Actividad_03 - COMMAND_V4.pdf)</th>
                <th>[Link](Actividad_04 - AJAX_V4.pdf)</th>
		<th>[Link](Actividad_05 - BASE DE DATOS_V4.pdf)</th>
       </tr>
    <tr>
        <th>Formulario Compra Productos</th>
        <th></th>
		<th>[Link](Actividad_01 - MAQUETACION_V5.pdf)</th>
		<th>[Link](Actividad_02 - VALIDACIONES_V5.pdf)</th>
		<th>[Link](Actividad_03 - COMMAND_V5.pdf)</th>
                <th>[Link](Actividad_04 - AJAX_V5.pdf)</th>
		<th>[Link](Actividad_05 - BASE DE DATOS_V5.pdf)</th>
       </tr>
</table>

### Actividad Trainng Desarrollo Semana 2

<table>
    <tr>
        <th>Nombre Actividad</th>
        <th>Descripción</th>
		<th>Maquetación Web - AJAX - Javascripts</th>
		<th>Base de Datos </th>
		<th>Encapsulamiento</th>
                <th>XML</th>
    </tr>
    <tr>
        <th>Chat</th>
        <th></th>
		<th>[Link](Actividad_01 - AVANZADO.pdf)</th>
		<th>[Link](Actividad_02 - AVANZADO.pdf)</th>
		<th>[Link](Actividad_03 - AVANZADO.pdf)</th>
                <th>[Link](Actividad_04 - AVANZADO.pdf)</th>
       </tr>
 <tr>
        <th>Productos</th>
        <th></th>
		<th>[Link](Actividad_02.1 - AVANZADO.pdf)</th>
		<th>[Link](Actividad_02.2 - AVANZADO.pdf)</th>
		<th>[Link](Actividad_02.3 - AVANZADO.pdf)</th>
                <th>[Link](Actividad_02.4 - AVANZADO.pdf)</th>
       </tr>
