Videotutorial
==========================
* Maquetacion Web parte 1

 * [Ver Video][maquetacionpart1]

[maquetacionpart1]: http://dev.facturacion.cl/Training/Videos/Capacitacion%20HTML%20-%20Estandar.mkv

* Maquetacion Web parte 2

 * [Ver Video][maquetacionpart2]

[maquetacionpart2]: http://dev.facturacion.cl/Training/Videos/Capacitacion%20HTML%20-%20Practico.mkv

* Base de Datos parte 1

 * [Ver Video][bdparte1]

[bdparte1]: http://dev.facturacion.cl/Training/Videos/Capacitacion%20Base%20de%20Datos%20teorico.mkv


* Base de Datos parte 2

 * [Ver Video][bdparte2]

[bdparte2]: http://dev.facturacion.cl/Training/Videos/Capacitacion%20Base%20de%20Datos.mkv


* Ajax Basico

 * [Ver Video][ajaxbasico]

[ajaxbasico]: http://dev.facturacion.cl/Training/Videos/ajax_clase.mp4

* Consultas a la Base de Datos con PHP

 * [Ver Video][BaseDatos]

[BaseDatos]: http://dev.facturacion.cl/Training/Videos/ajax_clase2.mp4


* Envío de parámetros vía GET y POST al servidor y manejo de datos con Javascript

 * [Ver Video][Ajax]

[Ajax]:http://dev.facturacion.cl/Training/Videos/ajax_clase3.mp4

* XML

 * [Ver Video][xml]

[xml]:http://dev.facturacion.cl/Training/Videos/xml.mkv
