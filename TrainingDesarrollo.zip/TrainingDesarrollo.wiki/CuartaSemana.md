# Planificación Training Desarrollo

<table>
    <tr>
        <th>Día</th>
        <th>Descripción</th>
		<th>Ubicación</th>
		<th>Hora de Inicio</th>
		<th>Hora de Término</th>
        <th>Contenido</th>
		<th>Tipo de Actividad</th>
		<th>Área Responsable</th>
		<th>Nombre de Responsable</th>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Capacitación Integración</td>
		<td></td>
		<td>08:45</td>
		<td>10:30</td>
		<td>Tipos de integración, Tipos de archivos, DTEPlanoWs, Webservices</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Kahoot! Integración</td>
		<td></td>
		<td>10:30</td>
		<td>10:45</td>
		<td>Tipos de integración, Tipos de archivos, DTEPlanoWs, Webservices</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Actividad practica - Integración</td>
		<td>201</td>
		<td>10:45</td>
		<td>11:15</td>
		<td>Tipos de integración, Tipos de archivos, DTEPlanoWs, Webservices</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Capacitación - Operaciones</td>
		<td></td>
		<td>11:15</td>
		<td>13:00</td>
		<td>Busqueda de clientes, Ordenes de Trabajo, Contactos, Videotutoriales, Requerimientos, Listado de Requerimientos</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Kahoot! - Operaciones</td>
		<td></td>
		<td>14:00</td>
		<td>14:15</td>
		<td>Busqueda de clientes, Ordenes de Trabajo, Contactos, Videotutoriales, Requerimientos, Listado de Requerimientos</td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Actividad Practica - Requerimientos</td>
		<td>201</td>
		<td>14:15</td>
		<td>16:00</td>
		<td>Busqueda de clientes, Ordenes de Trabajo, Contactos, Videotutoriales, Requerimientos, Listado de Requerimientos</td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Lectura Componente - Messagebox</td>
		<td></td>
		<td>16:00</td>
		<td>17:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>16</td>
		<td>Actividad Practica Componente - Messagebox</td>
		<td>201</td>
		<td>17:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>17</td>
		<td>Lectura Componente - Lightbox</td>
		<td></td>
		<td>08:45</td>
		<td>10:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>17</td>
		<td>Actividad Practica Componente - Lightbox</td>
		<td>201</td>
		<td>10:00</td>
		<td>12:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>17</td>
		<td>Lectura Componente - Datagrid 1,3</td>
		<td></td>
		<td>12:00</td>
		<td>13:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>17</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>17</td>
		<td>Actividad Practica Componente - Datagrid 1,3</td>
		<td>201</td>
		<td>14:00</td>
		<td>17:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>17</td>
		<td>Lectura Componente - Tooltip</td>
		<td></td>
		<td>17:00</td>
		<td>17:45</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>17</td>
		<td>Actividad Practica - Tooltip</td>
		<td>201</td>
		<td>17:45</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Lectura Componente - Envio email</td>
		<td></td>
		<td>08:45</td>
		<td>09:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Actividad Practica - Envio email</td>
		<td>201</td>
		<td>09:30</td>
		<td>10:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Lectura Componente - Envio email</td>
		<td></td>
		<td>08:45</td>
		<td>09:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Actividad Practica - Envio email</td>
		<td>201</td>
		<td>09:30</td>
		<td>10:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Lectura - Estandar PSR-2</td>
		<td></td>
		<td>10:30</td>
		<td>11:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Actividad Practica - Estandar PSR-2</td>
		<td>201</td>
		<td>11:30</td>
		<td>12:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Lectura - Postgresql</td>
		<td></td>
		<td>12:30</td>
		<td>13:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td>Wiki</td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Actividad Practica - Postgresql</td>
		<td>201</td>
		<td>14:00</td>
		<td>15:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>18</td>
		<td>Actividad Practica - Aplicando Estandar PSR-2 y Postgresql</td>
		<td>201</td>
		<td>15:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>19</td>
		<td>Capacitación - Revisión Funcional</td>
		<td></td>
		<td>08:45</td>
		<td>10:00</td>
		<td></td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>19</td>
		<td>Actividad Practica - Revisión Funcional</td>
		<td>201</td>
		<td>10:00</td>
		<td>13:00</td>
		<td></td>
		<td>Individual</td>
		<td>PD</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>19</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>19</td>
		<td>Capacitación - Revisión Técnica</td>
		<td></td>
		<td>14:00</td>
		<td>15:00</td>
		<td></td>
		<td>Grupal</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>19</td>
		<td>Actividad Practica - Revisión Técnica</td>
		<td>201</td>
		<td>15:00</td>
		<td>17:00</td>
		<td></td>
		<td>Individual</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>19</td>
		<td>Reforzamiento Estandares de Calidad y buenas practicas de desarrollo</td>
		<td></td>
		<td>17:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>20</td>
		<td>Asistencia a comite ART</td>
		<td></td>
		<td>09:00</td>
		<td>11:00</td>
		<td></td>
		<td>Individual</td>
		<td>PD</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>20</td>
		<td>Asignación de Requerimiento</td>
		<td></td>
		<td>09:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
