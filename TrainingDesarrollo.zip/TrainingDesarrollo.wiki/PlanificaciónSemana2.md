# Planificación Training Desarrollo

<table>
    <tr>
        <th>Día</th>
        <th>Descripción</th>
		<th>Ubicación</th>
		<th>Hora de Inicio</th>
		<th>Hora de Término</th>
        <th>Contenido</th>
		<th>Tipo de Actividad</th>
		<th>Área Responsable</th>
		<th>Nombre de Responsable</th>
    </tr>
    <tr>
        <td>6</td>
		<td>Capacitación Javascript Avanzado</td>
		<td>Sala de Reuniones 308</td>
		<td>09:00</td>
		<td>10:00</td>
		<td></td>
		<td>Grupal</td>
		<td>Desarrollo</td>
		<td>Fuad Acevedo</td>
    </tr>
	<tr>
        <td>6</td>
		<td>Asignación de Requerimiento Semanal</td>
		<td>Sala 201</td>
		<td>10:00</td>
		<td>10:15</td>
		<td></td>
		<td>Individual</td>
		<td>Encargado</td>
		<td>Jean Salazar</td>
	</tr>
	<tr>
        <td>6</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>10:15</td>
		<td>13:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>6</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>6</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>14:00</td>
		<td>16:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>6</td>
		<td>Aclaración de Dudas</td>
		<td>Sala de Reuniones 201</td>
		<td>16:00</td>
		<td>17:00</td>
		<td></td>
		<td>Individual</td>
		<td>Desarrollo</td>
		<td>Fuad Acevedo</td>
    </tr>
	</tr>
		<tr>
        <td>6</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>17:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td></td>
		<td></td>
    </tr>
	<tr>
        <td>7</td>
		<td>Capacitación Depuración de Errores y Flujos</td>
		<td>Sala de Reuniones 308</td>
		<td>08:45</td>
		<td>10:30</td>
		<td></td>
		<td>Grupal</td>
		<td>Desarrollo</td>
		<td>Fuad Acevedo</td>
    </tr>
	<tr>
        <td>7</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>10:00</td>
		<td>13:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>7</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	<tr>
        <td>7</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>14:00</td>
		<td>16:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>7</td>
		<td>Aclaración de Dudas</td>
		<td>Sala de Reuniones 201</td>
		<td>16:00</td>
		<td>17:00</td>
		<td></td>
		<td>Individual</td>
		<td>Desarrollo</td>
		<td>Fuad Acevedo</td>
    </tr>
	</tr>
		<tr>
        <td>7</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>17:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td></td>
		<td></td>
    </tr>
	<tr>
        <td>8</td>
		<td>Capacitación Base de Datos Avanzado</td>
		<td>Sala de Reuniones 308</td>
		<td>08:45</td>
		<td>10:00</td>
		<td></td>
		<td>Grupal</td>
		<td>QA</td>
		<td>Alejandro Martinez</td>
    </tr>
	<tr>
        <td>8</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>10:00</td>
		<td>13:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>8</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	<tr>
        <td>8</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>14:00</td>
		<td>16:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>8</td>
		<td>Aclaración de Dudas</td>
		<td>Sala de Reuniones 201</td>
		<td>16:00</td>
		<td>17:00</td>
		<td></td>
		<td>Individual</td>
		<td>Desarrollo</td>
		<td>Fuad Acevedo</td>
    </tr>
	</tr>
		<tr>
        <td>8</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>17:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td></td>
		<td></td>
    </tr>
	<tr>
        <td>9</td>
		<td>Capacitación XML</td>
		<td>Sala de Reuniones 204</td>
		<td>08:45</td>
		<td>10:00</td>
		<td></td>
		<td>Grupal</td>
		<td>Desarrollo</td>
		<td>Fuad Acevedo</td>
    </tr>
	<tr>
        <td>9</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>10:00</td>
		<td>13:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
    </tr>
		<tr>
        <td>9</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	<tr>
        <td>9</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>14:00</td>
		<td>16:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>9</td>
		<td>Aclaración de Dudas</td>
		<td>Sala de Reuniones 201</td>
		<td>16:00</td>
		<td>17:00</td>
		<td></td>
		<td>Individual</td>
		<td>Desarrollo</td>
		<td>Fuad Acevedo</td>
    </tr>
	</tr>
		<tr>
        <td>9</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>17:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>10</td>
		<td>Desarrollo Requerimiento Trainee</td>
		<td>Sala 201</td>
		<td>08:45</td>
		<td>13:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>10</td>
		<td>Almuerzo</td>
		<td></td>
		<td>13:00</td>
		<td>13:45</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>10</td>
		<td>Entrega Requerimiento</td>
		<td>Sala 201</td>
		<td>14:00</td>
		<td>14:30</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>10</td>
		<td>Capacitación Basica Sistema Facturación.cl</td>
		<td>Sala 201</td>
		<td>14:30</td>
		<td>16:00</td>
		<td></td>
		<td>Individual</td>
		<td>Trainee Desarrollo</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>10</td>
		<td>Revisión de observaciones Funcionales</td>
		<td>Sala 201</td>
		<td>16:00</td>
		<td>17:00</td>
		<td></td>
		<td>Individual</td>
		<td>Revisión Funcional</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>10</td>
		<td>Revisión de observaciones Técnicas</td>
		<td>Sala 201</td>
		<td>17:00</td>
		<td>18:00</td>
		<td></td>
		<td>Individual</td>
		<td>Revisión Técnica</td>
		<td></td>
    </tr>
	</tr>
		<tr>
        <td>10</td>
		<td>Feedback</td>
		<td>Sala 201</td>
		<td>18:00</td>
		<td>18:30</td>
		<td></td>
		<td>Individual</td>
		<td>Encargado Desarrollo</td>
		<td>Jean Salazar</td>
    </tr>
	<fieldset style="width: max-content;padding: 28px;">
		<legend  style="color: red">Semana 2</legend>
		<div id="contenido">
			<form>
				<table id="tablaContenido">
					<caption>Contenido</caption>
					<thead class="encabezado">
						<tr>
							<th>Lunes</th>
							<th>Martes</th>
							<th>Miercoles</th>
							<th>Jueves</th>
							<th>Viernes</th>
						</tr>
					</thead>
					<tbody class="cuerpo">
						<tr>
							<td>Javascript Avanzado</td>
							<td>Capacitación <br> Depuracion de Errores  <br> y Flujos</td>
							<td>Capacitacion <br> Base de Datos Avanzado</td>
							<td>Capacitacion XML</td>
							<td>Entrega y Revision <br> Videos Desis</td>
						</tr>
					</tbody>
				</table>
			</form>
		</div>
		<div id="detallecontenido">
			<table id="tabladetalle">
				<thead>
					<tr>
						<th>Javascript Avanzado</th>
						<th>Depuracion de Errores y Flujos</th>
						<th>Base de Datos Avanzado</th>
						<th>XML</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Encapsulamiento</td>
						<td rowspan="3">Uso y Manejo de Breakpoint Avanzado: <br> Navegador + JS <br> PHP  <br> SQL Manager</td>
						<td>Buenas Practicas: <br>  Uso y control de Flujo Avanzado<br>  Uso y manejo de Variables Avanzado</td>
						<td>Introducción de XML</td>
					</tr>
					<tr>
						<td>Uso y manejo de Herencia</td>
						<td rowspan="2">Uso de SQL:<br> Funciones Avanzado <br>Vistas Avanzado</td>
						<td rowspan="2">Uso y Manejo de Librerias de XML</td>
					</tr>
					<tr>
						<td>HTML DOM , Funciones y Condicionales Avanzados</td>
					</tr>
				</tbody>
			</table>
		</div>
	</fieldset>
